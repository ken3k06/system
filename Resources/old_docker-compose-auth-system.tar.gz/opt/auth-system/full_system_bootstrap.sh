#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# CONFIGURATION
# ============================================================
ENV_FILE=".env"
COMPOSE="docker compose"
PI_SERVICE="privacyidea"
PI_PERSIST="./pi_data"
PI_CFG="${PI_PERSIST}/pi.cfg"
NGINX_ROOT="./nginx"
SSL_DIR="${NGINX_ROOT}/ssl"
CONF_DIR="${NGINX_ROOT}/conf.d"
NGINX_MAIN_CONF="${NGINX_ROOT}/nginx.conf"
RADIUS_DIR="./freeradius"
RADIUS_CLIENTS_CONF="${RADIUS_DIR}/clients.conf"

PROVIDER_DIR="./providers"
PROVIDER_JAR="${PROVIDER_DIR}/privacyidea-keycloak-provider.jar"
PROVIDER_URL="https://github.com/privacyidea/keycloak-provider/releases/download/v1.6.0/PrivacyIDEA-Keycloak-Provider-1.6.0.jar"
EXPECTED_MD5="81c7be84b91cef54397bc14f4c5e287f"
TEMP_DOWNLOAD="/tmp/privacyidea_provider_2026.jar"

# ============================================================
# STEP 1: Deep Clean & Load Environment
# ============================================================
echo "[1/12] Deep cleaning environment and directories"

# Remove everything to ensure no corrupted files remain
rm -rf "$NGINX_ROOT" "$PI_PERSIST" "$RADIUS_DIR" "$PROVIDER_DIR"
rm -f "$TEMP_DOWNLOAD"

# Recreate fresh directory structure
mkdir -p "$NGINX_ROOT" "$CONF_DIR" "$SSL_DIR" "$RADIUS_DIR" "$PROVIDER_DIR" "$PI_PERSIST"

if [ -f "$ENV_FILE" ]; then
    set -a; source "$ENV_FILE"; set +a
    echo "✅ Environment variables loaded from $ENV_FILE"
else
    echo "❌ Error: $ENV_FILE not found"
    exit 1
fi

# ============================================================
# STEP 2: Download & Force MD5 Verification
# ============================================================
echo "[2/12] Downloading and Verifying Keycloak Provider v1.6.0"
echo "Downloading: $PROVIDER_URL"

curl -L -o "$TEMP_DOWNLOAD" "$PROVIDER_URL"

if [ ! -f "$TEMP_DOWNLOAD" ]; then
    echo "❌ Error: Download failed!"
    exit 1
fi

# Calculate MD5
ACTUAL_MD5=$(md5sum "$TEMP_DOWNLOAD" | awk '{print $1}')

echo "------------------------------------------------------------"
echo "Verification Results:"
echo "Expected MD5: $EXPECTED_MD5"
echo "Actual   MD5: $ACTUAL_MD5"
echo "------------------------------------------------------------"

if [ "$ACTUAL_MD5" == "$EXPECTED_MD5" ]; then
    mv "$TEMP_DOWNLOAD" "$PROVIDER_JAR"
    chmod 644 "$PROVIDER_JAR"
    echo "✅ SUCCESS: MD5 matches. Provider installed to $PROVIDER_JAR"
else
    echo "❌ CRITICAL ERROR: MD5 mismatch! The downloaded file is corrupted."
    rm -f "$TEMP_DOWNLOAD"
    exit 1
fi

# ============================================================
# STEP 3: Stop Existing Services
# ============================================================
echo "[3/12] Stopping Docker containers"
$COMPOSE down || true

# ============================================================
# STEP 4: Reset Remote Databases (PostgreSQL @ 10.0.9.121)
# ============================================================
echo "[4/12] Resetting PostgreSQL @ ${PI_DB_HOST}"
psql -h "$PI_DB_HOST" -U postgres <<EOF
SELECT pg_terminate_backend(pid) FROM pg_stat_activity 
WHERE datname IN ('${PI_DB_NAME}', '${KC_DB_NAME}');

DROP DATABASE IF EXISTS ${PI_DB_NAME};
DROP ROLE IF EXISTS ${PI_DB_USER};
CREATE ROLE ${PI_DB_USER} LOGIN PASSWORD '${PI_DB_PASSWORD}';
CREATE DATABASE ${PI_DB_NAME} OWNER ${PI_DB_USER};

DROP DATABASE IF EXISTS ${KC_DB_NAME};
DROP ROLE IF EXISTS ${KC_DB_USER};
CREATE ROLE ${KC_DB_USER} LOGIN PASSWORD '${KC_DB_PASS}';
CREATE DATABASE ${KC_DB_NAME} OWNER ${KC_DB_USER};

GRANT ALL PRIVILEGES ON DATABASE ${PI_DB_NAME} TO ${PI_DB_USER};
GRANT ALL PRIVILEGES ON DATABASE ${KC_DB_NAME} TO ${KC_DB_USER};
EOF

# ============================================================
# STEP 5: Generate EC SSL Certificates (10-Year Validity)
# ============================================================
echo "[5/12] Generating EC SSL for *.ctyabc.com"
openssl ecparam -name prime256v1 -genkey -noout -out "$SSL_DIR/server.key"
openssl req -new -x509 -nodes -key "$SSL_DIR/server.key" -out "$SSL_DIR/server.crt" -days 3650 \
    -subj "/C=VN/ST=Hanoi/L=Hanoi/O=CTYABC/CN=*.ctyabc.com" \
    -addext "subjectAltName = DNS:ctyabc.com, DNS:*.ctyabc.com, DNS:auth.ctyabc.com, DNS:mfa.ctyabc.com"

# ============================================================
# STEP 6: Configure Nginx
# ============================================================
echo "[6/12] Configuring Nginx (auth & mfa.ctyabc.com)"
cat <<EOF > "$NGINX_MAIN_CONF"
user nginx;
worker_processes auto;
events { worker_connections 1024; }
http {
    include /etc/nginx/mime.types;
    sendfile on;
    include /etc/nginx/conf.d/*.conf;
}
EOF

cat <<EOF > "$CONF_DIR/auth.conf"
server {
    listen 80; server_name auth.ctyabc.com;
    return 301 https://\$host\$request_uri;
}
server {
    listen 443 ssl; http2 on;
    server_name auth.ctyabc.com;
    ssl_certificate /etc/nginx/ssl/server.crt;
    ssl_certificate_key /etc/nginx/ssl/server.key;
    location / {
        proxy_pass http://keycloak:8080;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
EOF

cat <<EOF > "$CONF_DIR/mfa.conf"
server {
    listen 80; server_name mfa.ctyabc.com;
    return 301 https://\$host\$request_uri;
}
server {
    listen 443 ssl; http2 on;
    server_name mfa.ctyabc.com;
    ssl_certificate /etc/nginx/ssl/server.crt;
    ssl_certificate_key /etc/nginx/ssl/server.key;
    location / {
        proxy_pass http://privacyidea:8080;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

# ============================================================
# STEP 7: Configure FreeRADIUS Clients
# ============================================================
echo "[7/12] Configuring FreeRADIUS clients.conf"
cat <<EOF > "$RADIUS_CLIENTS_CONF"
client any {
    ipaddr = 0.0.0.0/0
    secret = ${RADIUS_CLIENT_SECRET}
    require_message_authenticator = no
}
EOF

# ============================================================
# STEP 8: Prepare PrivacyIDEA Config
# ============================================================
echo "[8/12] Preparing pi.cfg"
cat > "$PI_CFG" <<EOF
SQLALCHEMY_DATABASE_URI = 'postgresql://${PI_DB_USER}:${PI_DB_PASSWORD}@${PI_DB_HOST}:${PI_DB_PORT}/${PI_DB_NAME}'
SECRET_KEY = '${PI_SECRET_KEY}'
PI_PEPPER  = '${PI_PEPPER}'
PI_ENCFILE = '/privacyidea/etc/enckey'
PI_AUDIT_KEY_PRIVATE = '/privacyidea/etc/private.pem'
PI_AUDIT_KEY_PUBLIC  = '/privacyidea/etc/public.pem'
PI_BEHIND_PROXY = True
PI_EXTERNAL_URL = "https://mfa.ctyabc.com"
EOF

# ============================================================
# STEP 9: Initialize PrivacyIDEA DB & Keys
# ============================================================
echo "[9/12] Running PrivacyIDEA migrations"
$COMPOSE run --rm --entrypoint pi-manage privacyidea create_enckey
$COMPOSE run --rm --entrypoint pi-manage privacyidea create_audit_keys
$COMPOSE run --rm -e PI_CONFIG=/privacyidea/etc/pi.cfg --entrypoint pi-manage privacyidea create_tables

# ============================================================
# STEP 10: Create Admin User
# ============================================================
echo "[10/12] Creating PrivacyIDEA admin"
$COMPOSE run --rm --entrypoint pi-manage privacyidea admin add "$PI_ADMIN_USER" -p "$PI_ADMIN_PASSWORD" -e "$PI_ADMIN_EMAIL"

# ============================================================
# STEP 11: Final Launch
# ============================================================
echo "[11/12] Starting all services"
$COMPOSE up -d

# ============================================================
# STEP 12: Summary
# ============================================================
echo "✅ BOOTSTRAP COMPLETE (Jan 2026)"
echo "------------------------------------------------------------"
echo "Keycloak (Auth): https://auth.ctyabc.com"
echo "PrivacyIDEA (MFA): https://mfa.ctyabc.com"
echo "MD5 Verified: $EXPECTED_MD5"
echo "------------------------------------------------------------"

